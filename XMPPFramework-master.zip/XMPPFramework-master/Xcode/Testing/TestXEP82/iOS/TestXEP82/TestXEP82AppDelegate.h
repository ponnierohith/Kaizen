#import <UIKit/UIKit.h>

@class TestXEP82ViewController;


@interface TestXEP82AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet TestXEP82ViewController *viewController;

@end
