//
//  main.m
//  AutoTimeTest
//
//  Created by Robbie Hanson on 9/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AutoTimeTestAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AutoTimeTestAppDelegate class]));
    }
}
